from django.apps import AppConfig


class AboutmeConfig(AppConfig):
    name = 'aboutme'
